library(ez)
library(rstatix)


# 0. DATA PREPARATION

# 0.1. loading data

replication_data = read.csv("replication_data.csv")

main_data = read.csv("main_data.csv")

main_data_sumActivatoin = read.csv("main_data_sumActivatoin.csv")


# 0.2. converting vars to factor class

replication_data[,'net_num']<-factor(replication_data[,'net_num'])
replication_data[,'ExtraPeri']<-factor(replication_data[,'ExtraPeri'])
replication_data[,'FrontoTemp']<-factor(replication_data[,'FrontoTemp'])
replication_data[,'Centrality']<-factor(replication_data[,'Centrality'])
replication_data[,'WordType']<-factor(replication_data[,'WordType'])

main_data[,'net_num']<-factor(main_data[,'net_num'])
main_data[,'ExtraPeri']<-factor(main_data[,'ExtraPeri'])
main_data[,'FrontoTemp']<-factor(main_data[,'FrontoTemp'])
main_data[,'Centrality']<-factor(main_data[,'Centrality'])
main_data[,'WordType']<-factor(main_data[,'WordType'])
main_data[,'SDType']<-factor(main_data[,'SDType'])
main_data[,'Severity']<-factor(main_data[,'Severity'])

main_data_sumActivatoin[,'net_num']<-factor(main_data_sumActivatoin[,'net_num'])
main_data_sumActivatoin[,'ExtraPeri']<-factor(main_data_sumActivatoin[,'ExtraPeri'])
main_data_sumActivatoin[,'WordType']<-factor(main_data_sumActivatoin[,'WordType'])
main_data_sumActivatoin[,'SDType']<-factor(main_data_sumActivatoin[,'SDType'])
main_data_sumActivatoin[,'Severity']<-factor(main_data_sumActivatoin[,'Severity'])

# 0.3.checking for ANOVA assumptions -- outliers and normality

# data for replication
outliers_repl_data <-replication_data %>%
  group_by( area, WordType) %>%
  identify_outliers(activation)
outliers_rate_repl = length(which(outliers_repl_data$is.extreme))/length(replication_data$area) # < 1% -- ok

normality_repl <- subset(replication_data, area != 'V1' & area != 'M1-L') %>%
  group_by( area, WordType) %>%
  shapiro_test(activation)
normality_repl_problems <- subset(normality_repl, p < 0.05) 
abnormality_rate_repl = length(normality_repl_problems$p)/length(normality_repl$p)  # = 0 -- ok

normality_replV1 <- subset(replication_data, area == 'V1' & WordType == 'object') %>%
  group_by( area, WordType) %>%
  shapiro_test(activation)
normality_replV1_problems <- subset(normality_replV1, p < 0.05)
abnormality_rate_replV1 = length(normality_replV1_problems$p)/length(normality_replV1$p) # = 0 -- ok

normality_replM1 <- subset(replication_data, area == 'M1-L' & WordType == 'action') %>%
  group_by( area, WordType) %>%
  shapiro_test(activation)
normality_replM1_problems <- subset(normality_replM1, p < 0.05) 
abnormality_rate_replM1 = length(normality_replM1_problems$p)/length(normality_replM1$p) # = 0 -- ok

# main data
outliers_mian_data <-main_data %>%
  group_by( area, WordType, SDType, Severity) %>%
  identify_outliers(activation)
outliers_rate_main <- length(which(outliers_mian_data$is.extreme))/length(main_data$area) # = 1% -- ok

normality_main <- subset(main_data, area != 'V1' & area != 'M1-L') %>%
  group_by( area, WordType, SDType, Severity) %>%
  shapiro_test(activation)
normality_main_problems <- subset(normality_main, p < 0.05)  
abnormality_rate_main = length(normality_main_problems$p)/length(normality_main$p) # = 6% -- ok

normality_mainV1 <- subset(main_data, area == 'V1' & WordType == 'object') %>%
  group_by( area, WordType, SDType, Severity) %>%
  shapiro_test(activation)
normality_mainV1_problems <- subset(normality_mainV1, p < 0.05)  
abnormality_rate_mainV1 = length(normality_mainV1_problems$p)/length(normality_mainV1$p) # = 0 -- ok

normality_mainM1 <- subset(main_data, area == 'M1-L' & WordType == 'action') %>%
  group_by( area, WordType, SDType, Severity) %>%
  shapiro_test(activation)
normality_mainM1_problems <- subset(normality_mainM1, p < 0.05)  
abnormality_rate_mainM1 = length(normality_mainM1_problems$p)/length(normality_mainM1$p) # = 0 -- ok


# main data with sum of activations
outliers_main_sum_data <- main_data_sumActivatoin %>%
  group_by(ExtraPeri, WordType, SDType, Severity) %>%
  identify_outliers(activation)
outliers_rate_main_sum <- length(which(outliers_main_sum_data$is.extreme))/length(main_data_sumActivatoin$ExtraPeri)  # < 0.5% -- ok

normality_main_sum <- main_data_sumActivatoin %>%
  group_by( ExtraPeri, WordType, SDType, Severity) %>%
  shapiro_test(activation)
normality_main_sum_problems <- subset(normality_main_sum, p < 0.05) 
abnormality_rate_main_sum = length(normality_main_sum_problems$p)/length(normality_main_sum$p) # = 0 -- ok

normality_main_sumV1 <- main_data_sumActivatoin %>%
  group_by( ExtraPeri, WordType, SDType, Severity) %>%
  shapiro_test(activation)
normality_main_sumV1_problems <- subset(normality_main_sumV1, p < 0.05)  
abnormality_rate_mainV1_sum = length(normality_main_sumV1_problems$p)/length(normality_main_sumV1$p) # = 0 -- ok

normality_main_sumM1 <- main_data_sumActivatoin %>%
  group_by( ExtraPeri, WordType, SDType, Severity) %>%
  shapiro_test(activation)
normality_main_sumM1_problems <- subset(normality_main_sumM1, p < 0.05) 
abnormality_rate_mainM1_sum = length(normality_main_sumM1_problems$p)/length(normality_main_sumM1$p) # = 0 -- ok




# 1. ANOVAs FOR G&P 2016 REPLICATION

# 1.1 4-way anova

rt_anova_repl_4w = ezANOVA(
  data = replication_data,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(ExtraPeri, FrontoTemp, Centrality, WordType)
)
print(rt_anova_repl_4w)
capture.output(rt_anova_repl_4w, file="anova_replication_4way.txt")

# 1.2 3-way anova x2 (separately for extra and peri)

replication_data_extra = subset(replication_data, ExtraPeri == 'extra')
replication_data_peri = subset(replication_data, ExtraPeri == 'peri')

rt_anova_repl_3w_extra = ezANOVA(
  data = replication_data_extra,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(FrontoTemp, Centrality, WordType)
)
print(rt_anova_repl_3w_extra)
capture.output(rt_anova_repl_3w_extra, file="anova_replication_3way_extra.txt")


rt_anova_repl_3w_peri = ezANOVA(
  data = replication_data_peri,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(FrontoTemp, Centrality, WordType)
)
print(rt_anova_repl_3w_peri)
capture.output(rt_anova_repl_3w_peri, file="anova_replication_3way_peri.txt")




# 2. ANOVAs FOR CURRENT EXPERIMENT -- MAIN PART 

# 2.1 6-way anova

rt_anova_main_6w = ezANOVA(
  data = main_data,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(ExtraPeri, FrontoTemp, Centrality, WordType, SDType, Severity)
)
print(rt_anova_main_6w)
capture.output(rt_anova_main_6w, file="anova_main_6way.txt")


# 2.2 2-way anova

rt_anova_main_2w = ezANOVA(
  data = main_data,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(ExtraPeri, Severity)
  , within_full = .(FrontoTemp, Centrality, WordType, SDType)
)
print(rt_anova_main_2w)
capture.output(rt_anova_main_2w, file="anova_main_2way.txt")


# 2.3 3-way anova x2 (summed activation in six areas, separately for extra and peri) 

main_data_sumActivatoin_extra = subset(main_data_sumActivatoin, ExtraPeri == 'extra')
main_data_sumActivatoin_peri = subset(main_data_sumActivatoin, ExtraPeri == 'peri')

rt_anova_main_3w_extra = ezANOVA(
  data = main_data_sumActivatoin_extra,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(WordType, SDType, Severity)
)
print(rt_anova_main_3w_extra)
capture.output(rt_anova_main_3w_extra, file="anova_main_3way_extra.txt")

rt_anova_main_3w_peri = ezANOVA(
  data = main_data_sumActivatoin_peri,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(WordType, SDType, Severity)
)
print(rt_anova_main_3w_peri)
capture.output(rt_anova_main_3w_peri, file="anova_main_3way_peri.txt")

# 2.4 2-way anova x4 (separately for obj_GM, obj_WM, act_GM and act_WM) 

main_data_sumActivatoin_obj_GM = subset(main_data_sumActivatoin, WordType == 'object' & SDType == 'GM')
main_data_sumActivatoin_obj_WM = subset(main_data_sumActivatoin, WordType == 'object' & SDType == 'WM')
main_data_sumActivatoin_act_GM = subset(main_data_sumActivatoin, WordType == 'action' & SDType == 'GM')
main_data_sumActivatoin_act_WM = subset(main_data_sumActivatoin, WordType == 'action' & SDType == 'WM')

rt_anova_main_2w_obj_GM = ezANOVA(
  data = main_data_sumActivatoin_obj_GM,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(ExtraPeri, Severity)
)
print(rt_anova_main_2w_obj_GM)
capture.output(rt_anova_main_2w_obj_GM, file="anova_main_2way_obj_GM.txt")

rt_anova_main_2w_obj_WM = ezANOVA(
  data = main_data_sumActivatoin_obj_WM,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(ExtraPeri, Severity)
)
print(rt_anova_main_2w_obj_WM)
capture.output(rt_anova_main_2w_obj_WM, file="anova_main_2way_obj_WM.txt")

rt_anova_main_2w_act_GM = ezANOVA(
  data = main_data_sumActivatoin_act_GM,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(ExtraPeri, Severity)
)
print(rt_anova_main_2w_act_GM)
capture.output(rt_anova_main_2w_act_GM, file="anova_main_2way_act_GM.txt")

rt_anova_main_2w_act_WM = ezANOVA(
  data = main_data_sumActivatoin_act_WM,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(ExtraPeri, Severity)
)
print(rt_anova_main_2w_act_WM)
capture.output(rt_anova_main_2w_act_WM, file="anova_main_2way_act_WM.txt")




# 3. ANOVAs FOR CURRENT EXPERIMENT -- EXPLORATORY PART 

# 3.1 2-way anova x2 (only for extra areas, separately for GM and WM) 

main_data_sumActivatoin_extra_GM = subset(main_data_sumActivatoin, ExtraPeri == 'extra' & SDType == 'GM')
main_data_sumActivatoin_extra_WM = subset(main_data_sumActivatoin, ExtraPeri == 'extra' & SDType == 'WM')

rt_anova_explor_2w_extra_GM = ezANOVA(
  data = main_data_sumActivatoin_extra_GM,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(WordType, Severity)
)
print(rt_anova_explor_2w_extra_GM)
capture.output(rt_anova_explor_2w_extra_GM, file="anova_explor_2way_extra_GM.txt")

rt_anova_explor_2w_extra_WM = ezANOVA(
  data = main_data_sumActivatoin_extra_WM,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(WordType, Severity)
)
print(rt_anova_explor_2w_extra_WM)
capture.output(rt_anova_explor_2w_extra_WM, file="anova_explor_2way_extra_WM.txt")


# 3.2 2-way anova x2 (only for extra areas, separately for obj and act) 

main_data_sumActivatoin_extra_obj = subset(main_data_sumActivatoin, ExtraPeri == 'extra' & WordType == 'object')
main_data_sumActivatoin_extra_act = subset(main_data_sumActivatoin, ExtraPeri == 'extra' & WordType == 'action')

rt_anova_explor_2w_extra_obj = ezANOVA(
  data = main_data_sumActivatoin_extra_obj,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(SDType, Severity)
)
print(rt_anova_explor_2w_extra_obj)
capture.output(rt_anova_explor_2w_extra_obj, file="anova_explor_2way_extra_obj.txt")

rt_anova_explor_2w_extra_act = ezANOVA(
  data = main_data_sumActivatoin_extra_act,
  dv = .(activation)
  , wid = .(net_num)
  , within = .(SDType, Severity)
)
print(rt_anova_explor_2w_extra_act)
capture.output(rt_anova_explor_2w_extra_act, file="anova_explor_2way_extra_act.txt")
